
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `
Você é o assistente virtual da Innova Digital, uma empresa brasileira líder em tecnologia para saúde.
Seu objetivo é ajudar potenciais clientes (médicos, gestores hospitalares e profissionais de saúde) a entender como a tecnologia pode melhorar seus processos.

Principais soluções da Innova Digital:
1. Software sob medida para fluxos clínicos.
2. Gestão e monitoramento hospitalar.
3. Apps de apoio à decisão clínica e cuidado contínuo.
4. Consultoria em segurança de dados e LGPD na saúde.

Seja profissional, ético, prestativo e foque em inovação com segurança. Responda em Português do Brasil.
Se perguntarem algo fora de tecnologia em saúde, tente gentilmente trazer o assunto de volta para o impacto da tecnologia no cuidado humano.
`;

export const getGeminiResponse = async (userPrompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history,
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topP: 0.95,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Desculpe, tive um problema técnico ao processar sua solicitação. Por favor, tente novamente em instantes.";
  }
};
