
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Differentials from './components/Differentials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AIConsultant from './components/AIConsultant';

const VisionBanner: React.FC = () => (
  <section className="w-full py-20 bg-primary text-white text-center px-6">
    <div className="max-w-[900px] mx-auto">
      <span className="text-white/70 uppercase tracking-widest text-sm font-bold mb-4 block">Nosso Propósito</span>
      <h2 className="text-3xl md:text-5xl font-extrabold leading-tight mb-8">
        Ser a ponte entre a inovação digital e o cuidado humano, elevando os padrões da saúde brasileira.
      </h2>
      <div className="h-1 w-24 bg-white/30 mx-auto rounded-full"></div>
    </div>
  </section>
);

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col font-display">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <About />
        <Services />
        <Differentials />
        <VisionBanner />
        <Contact />
      </main>
      <Footer />
      <AIConsultant />
    </div>
  );
};

export default App;
