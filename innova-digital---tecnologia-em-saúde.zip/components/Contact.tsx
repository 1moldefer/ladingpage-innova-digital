
import React from 'react';

const Contact: React.FC = () => {
  const contactInfo = [
    { icon: 'mail', label: 'E-mail', value: 'contato@innovadigital.com.br' },
    { icon: 'chat_bubble', label: 'WhatsApp', value: '+55 (82) 99999-0000' },
    { icon: 'location_on', label: 'Endereço', value: 'Av. Empresarial, 123 - Maceió/AL' },
  ];

  return (
    <section className="py-20 bg-background-light dark:bg-background-dark" id="contato">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-10">
        <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl overflow-hidden grid lg:grid-cols-2">
          <div className="p-10 lg:p-16 flex flex-col justify-center">
            <h2 className="text-[#0d141b] dark:text-slate-50 text-3xl font-extrabold mb-8">Vamos transformar a saúde juntos?</h2>
            <div className="space-y-6">
              {contactInfo.map((info, idx) => (
                <div key={idx} className="flex items-start gap-4">
                  <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-primary">{info.icon}</span>
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 uppercase font-bold tracking-wider">{info.label}</p>
                    <p className="text-lg font-medium dark:text-slate-200">{info.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-primary p-10 lg:p-16 flex flex-col items-center justify-center text-center">
            <h3 className="text-white text-2xl font-bold mb-4">Pronto para começar?</h3>
            <p className="text-white/80 mb-8 max-w-[300px]">Nossa equipe está preparada para entender seu desafio e propor a melhor solução tecnológica.</p>
            <button className="w-full max-w-[300px] bg-white text-primary h-14 rounded-xl font-extrabold text-lg shadow-lg hover:bg-slate-100 transition-colors uppercase tracking-wide">
              Entrar em contato
            </button>
            <p className="text-white/50 text-xs mt-6">Resposta em até 24h úteis.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
