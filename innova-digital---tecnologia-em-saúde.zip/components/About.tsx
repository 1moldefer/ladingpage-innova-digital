
import React from 'react';

const About: React.FC = () => {
  const values = [
    { icon: 'shield', title: 'Segurança', desc: 'Dados protegidos sob rigorosos protocolos.' },
    { icon: 'gavel', title: 'Ética', desc: 'Compromisso total com a integridade digital.' },
    { icon: 'speed', title: 'Performance', desc: 'Sistemas ágeis para ambientes críticos.' },
    { icon: 'hub', title: 'Conectividade', desc: 'Ecossistemas integrados e escaláveis.' },
  ];

  return (
    <section className="py-20 bg-white dark:bg-background-dark" id="sobre">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="flex flex-col gap-6">
            <span className="text-primary font-bold tracking-widest uppercase text-xs">Sobre nós</span>
            <h2 className="text-[#0d141b] dark:text-slate-50 text-3xl md:text-4xl font-extrabold leading-tight">Inovação com propósito e segurança.</h2>
            <p className="text-slate-600 dark:text-slate-400 text-lg leading-relaxed">
              Focada no desenvolvimento de software de alta performance, a <span className="text-primary font-bold">Innova Digital</span> combina responsabilidade ética com o mais alto rigor em segurança da informação.
            </p>
            <p className="text-slate-600 dark:text-slate-400 text-lg leading-relaxed">
              Transformamos a tecnologia em saúde em um diferencial estratégico para nossos parceiros, garantindo que profissionais possam focar no que realmente importa: o bem-estar do paciente.
            </p>
          </div>
          <div className="bg-primary/5 dark:bg-primary/10 rounded-2xl p-8 border border-primary/10">
            <div className="grid grid-cols-2 gap-8">
              {values.map((v, i) => (
                <div key={i} className="flex flex-col gap-2">
                  <span className="material-symbols-outlined text-primary text-4xl">{v.icon}</span>
                  <h4 className="font-bold text-[#0d141b] dark:text-slate-100">{v.title}</h4>
                  <p className="text-sm text-slate-500">{v.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
