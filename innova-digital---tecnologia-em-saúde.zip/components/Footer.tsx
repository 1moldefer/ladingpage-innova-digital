
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0a1118] text-white py-16 border-t border-slate-800">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-10">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="size-6 text-primary">
                <svg fill="none" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
                  <path d="M13.8261 17.4264C16.7203 18.1174 20.2244 18.5217 24 18.5217C27.7756 18.5217 31.2797 18.1174 34.1739 17.4264C36.9144 16.7722 39.9967 15.2331 41.3563 14.1648L24.8486 40.6391C24.4571 41.267 23.5429 41.267 23.1514 40.6391L6.64374 14.1648C8.00331 15.2331 11.0856 16.7722 13.8261 17.4264Z" fill="currentColor"></path>
                </svg>
              </div>
              <h4 className="font-bold text-lg">Innova Digital</h4>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed max-w-[250px]">
              Tecnologia a serviço da saúde. Elevando os padrões de segurança e inovação no Brasil.
            </p>
          </div>
          <div>
            <h5 className="font-bold mb-6 text-slate-300">Navegação</h5>
            <ul className="space-y-3 text-sm text-slate-400">
              <li><a className="hover:text-primary transition-colors" href="#sobre">Sobre Nós</a></li>
              <li><a className="hover:text-primary transition-colors" href="#solucoes">Nossas Soluções</a></li>
              <li><a className="hover:text-primary transition-colors" href="#diferenciais">Diferenciais</a></li>
              <li><a className="hover:text-primary transition-colors" href="#contato">Fale Conosco</a></li>
            </ul>
          </div>
          <div>
            <h5 className="font-bold mb-6 text-slate-300">Institucional</h5>
            <p className="text-sm text-slate-400 mb-2">CNPJ: 00.000.000/0001-00</p>
            <p className="text-sm text-slate-400 mb-2">Maceió - Alagoas</p>
            <p className="text-sm text-slate-400">© 2024 Innova Digital. Todos os direitos reservados.</p>
          </div>
        </div>
        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-slate-500 uppercase tracking-widest">Inovação • Ética • Segurança</p>
          <div className="flex gap-6">
            <a className="text-slate-500 hover:text-white transition-colors" href="#"><span className="material-symbols-outlined">share</span></a>
            <a className="text-slate-500 hover:text-white transition-colors" href="#"><span className="material-symbols-outlined">account_circle</span></a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
