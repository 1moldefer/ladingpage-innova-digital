
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="w-full bg-primary relative overflow-hidden">
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
      <div className="max-w-[1200px] mx-auto px-6 lg:px-10 py-20 lg:py-32 flex flex-col items-start relative z-10">
        <div className="max-w-[700px] flex flex-col gap-6 animate-in fade-in slide-in-from-left-8 duration-700">
          <h1 className="text-white text-4xl md:text-6xl font-extrabold leading-[1.1] tracking-tight">
            Tecnologia digital a serviço da saúde.
          </h1>
          <p className="text-white/90 text-lg md:text-xl font-normal leading-relaxed">
            Desenvolvemos soluções digitais seguras e inovadoras para apoiar profissionais, instituições de saúde e cuidadores em uma nova era de cuidado.
          </p>
          <div className="pt-4 flex flex-wrap gap-4">
            <button className="flex min-w-[200px] cursor-pointer items-center justify-center rounded-lg h-14 px-8 bg-white text-primary text-base font-extrabold tracking-wide hover:bg-slate-50 transition-colors shadow-xl">
              Fale com a Innova Digital
            </button>
          </div>
        </div>
      </div>
      {/* Abstract Decoration */}
      <div className="absolute right-0 bottom-0 w-1/3 h-full hidden lg:block" style={{ background: 'linear-gradient(135deg, transparent 0%, rgba(255,255,255,0.1) 100%)', clipPath: 'polygon(100% 0, 0% 100%, 100% 100%)' }}></div>
    </section>
  );
};

export default Hero;
