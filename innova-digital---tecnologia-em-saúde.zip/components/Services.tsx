
import React from 'react';
import { ServiceCardProps } from '../types';

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description }) => (
  <div className="bg-white dark:bg-background-dark p-8 rounded-xl border border-[#e7edf3] dark:border-slate-800 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group">
    <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
      <span className="material-symbols-outlined">{icon}</span>
    </div>
    <h3 className="text-lg font-bold mb-3 dark:text-slate-100">{title}</h3>
    <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{description}</p>
  </div>
);

const Services: React.FC = () => {
  const services: ServiceCardProps[] = [
    { icon: 'code', title: 'Software sob medida', description: 'Desenvolvimento focado nas particularidades do seu fluxo de trabalho clínico.' },
    { icon: 'domain', title: 'Soluções para hospitais', description: 'Sistemas de gestão e monitoramento para instituições de grande escala.' },
    { icon: 'stay_current_portrait', title: 'Aplicativos de apoio', description: 'Ferramentas mobile para suporte à decisão e cuidado contínuo.' },
    { icon: 'verified_user', title: 'Tecnologia e Conformidade', description: 'Auditoria e implementação de padrões de segurança e LGPD.' },
  ];

  return (
    <section className="py-20 bg-background-light dark:bg-slate-900/50" id="solucoes">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-10">
        <div className="text-center max-w-[800px] mx-auto mb-16">
          <h2 className="text-[#0d141b] dark:text-slate-50 text-3xl md:text-4xl font-extrabold mb-4">O que fazemos</h2>
          <p className="text-slate-600 dark:text-slate-400 text-lg">Desenvolvemos o futuro da saúde digital através de soluções robustas e personalizadas para as necessidades do setor.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((s, i) => (
            <ServiceCard key={i} {...s} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
